package question1;

import java.io.*; 
import java.util.*; 

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text; 
import org.apache.hadoop.io.LongWritable; 
import org.apache.hadoop.mapreduce.Mapper; 

public class new_Mapper extends Mapper<Object, Text, Text, FloatWritable> { 

	private TreeMap<String,Float> tmap; 

	@Override
	public void setup(Context context) throws IOException, 
									InterruptedException 
	{ 
		tmap = new TreeMap<String,Float>(); 
	} 

	@Override
	public void map(Object key, Text value,	Context context) throws IOException,InterruptedException 
	{ 

		String line = value.toString();
		
		//Checking if the line is not empty
			
			if (!(line.length() == 0)) 
			{
				String date = line.substring(6, 10);				
				Float temp_Max = Float.parseFloat(line.substring(39, 45).trim());

				tmap.put( date,temp_Max); 
				//tmap.put(date, temp_Min); 

				if (tmap.size() > 10) 
				{ 
					tmap.remove(tmap.firstKey()); 
				} 
			} 		
	}

	@Override
	public void cleanup(Context context) throws IOException, 
									InterruptedException 
	{ 
		for (Map.Entry<String,Float> entry : tmap.entrySet()) 
		{ 

			String count = entry.getKey(); 
			 float  name = entry.getValue(); 

			context.write(new Text(count), new FloatWritable(name)); 
		} 
	} 
} 
